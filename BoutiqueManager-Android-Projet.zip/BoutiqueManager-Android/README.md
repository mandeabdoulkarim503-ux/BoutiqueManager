# BoutiqueManager Android — Projet natif

## Ce que contient cette version
- Application Android native Kotlin + Jetpack Compose.
- Base locale Room/SQLite, utilisable hors connexion.
- Tableau de bord : chiffre d'affaires, bénéfice estimé, produits et ventes.
- Gestion des produits, prix d'achat/vente et stock.
- Enregistrement des ventes avec diminution du stock.
- Enregistrement des dépenses.
- Champs client et vendeur pour une vente.

## Obtenir l'APK depuis un téléphone Android
1. Téléchargez et décompressez ce projet.
2. Créez un dépôt GitHub nommé `BoutiqueManager`.
3. Dans le navigateur Android, ouvrez le dépôt et téléversez tous les fichiers et dossiers du projet en conservant leur structure.
4. Ouvrez l'onglet **Actions** et autorisez les workflows si demandé.
5. Lancez **Build BoutiqueManager APK** avec **Run workflow**.
6. À la fin, ouvrez l'exécution et téléchargez l'artefact `BoutiqueManager-debug-apk`.
7. Décompressez l'artefact et installez `app-debug.apk`. Android peut demander l'autorisation d'installer depuis cette source.

## Limites de cette première version native
L'APK n'est pas précompilé dans cette archive. La compilation GitHub Actions doit réussir avant que l'APK puisse être installé.
Cette version ne comprend pas encore les factures PDF, les sauvegardes exportables, les comptes multi-utilisateurs, la synchronisation cloud ni les paiements. Ces éléments seront ajoutés ensuite.
Les données sont locales à l'appareil. Désinstaller l'application peut les supprimer. Testez avec des données fictives avant une utilisation commerciale.
