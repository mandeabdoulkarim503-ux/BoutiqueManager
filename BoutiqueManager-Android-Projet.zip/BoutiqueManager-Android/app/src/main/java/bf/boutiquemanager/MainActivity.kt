package bf.boutiquemanager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import bf.boutiquemanager.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val green=Color(0xFF123B32)
private fun money(v:Long)=NumberFormat.getIntegerInstance(Locale.FRANCE).format(v)+" FCFA"

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val dao=StoreDatabase.get(this).dao()
  setContent { MaterialTheme(colorScheme=lightColorScheme(primary=green,secondary=Color(0xFF1D6B55))) { App(dao) } }
 }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(dao:StoreDao){
 var tab by remember{mutableIntStateOf(0)}
 val products by dao.products().collectAsState(initial=emptyList())
 val sales by dao.sales().collectAsState(initial=emptyList())
 val expenses by dao.expenses().collectAsState(initial=emptyList())
 Scaffold(topBar={TopAppBar(title={Text("BoutiqueManager",fontWeight=FontWeight.Bold)})},
 bottomBar={NavigationBar{
  listOf("Accueil","Stock","Ventes","Dépenses").forEachIndexed{i,s->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(listOf(Icons.Default.Home,Icons.Default.Inventory,Icons.Default.PointOfSale,Icons.Default.Receipt)[i],null)},label={Text(s)})}
 }}){pad->Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)){
  when(tab){
   0->{val rev=sales.sumOf{it.qty*it.price};val profit=rev-sales.sumOf{it.qty*it.cost}-expenses.sumOf{it.amount}
    Text("Bonjour 👋",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
    Text("Vue générale de votre commerce",color=Color.Gray)
    Spacer(Modifier.height(16.dp))
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Metric("Chiffre d'affaires",money(rev),Modifier.weight(1f));Metric("Bénéfice estimé",money(profit),Modifier.weight(1f))}
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Metric("Produits",products.size.toString(),Modifier.weight(1f));Metric("Ventes",sales.size.toString(),Modifier.weight(1f))}
    Spacer(Modifier.height(12.dp));Text("Stock à surveiller",fontWeight=FontWeight.Bold)
    Text("${products.count{it.qty<=it.alert}} produit(s) au seuil d'alerte.",color=Color(0xFF9A6500))
    Text("Données conservées localement sur cet appareil.",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
   }
   1->Stock(products,dao)
   2->Sell(products,dao)
   3->Expenses(expenses,dao)
  }
 }}
}
@Composable fun Metric(t:String,v:String,m:Modifier=Modifier){Card(m){Column(Modifier.padding(12.dp)){Text(t,color=Color.Gray);Text(v,fontWeight=FontWeight.Bold)}}}
@Composable fun NumField(v:String,on:(String)->Unit,label:String,m:Modifier=Modifier){OutlinedTextField(v,on,{ },label={Text(label)},modifier=m,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)}
@Composable fun Stock(items:List<Product>,dao:StoreDao){
 val scope= rememberCoroutineScope();var name by remember{mutableStateOf("")};var buy by remember{mutableStateOf("")};var sell by remember{mutableStateOf("")};var qty by remember{mutableStateOf("")}
 Text("Produits & stock",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
 OutlinedTextField(name,{name=it},label={Text("Nom du produit")},modifier=Modifier.fillMaxWidth())
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){NumField(buy,{buy=it},"Prix achat",Modifier.weight(1f));NumField(sell,{sell=it},"Prix vente",Modifier.weight(1f))}
 NumField(qty,{qty=it},"Quantité",Modifier.fillMaxWidth())
 Button(onClick={val b=buy.toLongOrNull();val s=sell.toLongOrNull();val q=qty.toIntOrNull();if(name.isNotBlank()&&b!=null&&s!=null&&q!=null&&b>=0&&s>=0&&q>=0)scope.launch{dao.addProduct(Product(name=name.trim(),buy=b,sell=s,qty=q));name="";buy="";sell="";qty=""}},modifier=Modifier.fillMaxWidth()){Text("Ajouter le produit")}
 Spacer(Modifier.height(12.dp))
 LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(items,key={it.id}){p->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("Achat ${money(p.buy)} · Vente ${money(p.sell)}");Text("Stock : ${p.qty}",color=if(p.qty<=p.alert)Color(0xFF9A6500) else green)};IconButton(onClick={scope.launch{dao.delete(p)}}){Icon(Icons.Default.Delete,"Supprimer")}}}}}
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Sell(items:List<Product>,dao:StoreDao){
 val scope= rememberCoroutineScope();var selected by remember{mutableStateOf<Product?>(null)};var expanded by remember{mutableStateOf(false)}
 var qty by remember{mutableStateOf("1")};var customer by remember{mutableStateOf("")};var seller by remember{mutableStateOf("")}
 Text("Enregistrer une vente",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
 ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}){
  OutlinedTextField(selected?.name?:"Choisir un produit",{},readOnly=true,label={Text("Produit")},modifier=Modifier.menuAnchor().fillMaxWidth())
  ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){items.filter{it.qty>0}.forEach{p->DropdownMenuItem(text={Text("${p.name} (${p.qty})")},onClick={selected=p;expanded=false})}}
 }
 NumField(qty,{qty=it},"Quantité",Modifier.fillMaxWidth())
 OutlinedTextField(customer,{customer=it},label={Text("Client facultatif")},modifier=Modifier.fillMaxWidth())
 OutlinedTextField(seller,{seller=it},label={Text("Vendeur")},modifier=Modifier.fillMaxWidth())
 Button(onClick={val n=qty.toIntOrNull();val p=selected;if(p!=null&&n!=null&&n>0&&n<=p.qty)scope.launch{if(dao.decrease(p.id,n)>0)dao.addSale(Sale(productName=p.name,qty=n,price=p.sell,cost=p.buy,customer=customer,seller=seller));selected=null;qty="1";customer="";seller=""}},modifier=Modifier.fillMaxWidth()){Text("Valider la vente")}
}
@Composable fun Expenses(items:List<Expense>,dao:StoreDao){
 val scope= rememberCoroutineScope();var label by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")}
 Text("Dépenses",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
 OutlinedTextField(label,{label=it},label={Text("Motif")},modifier=Modifier.fillMaxWidth())
 NumField(amount,{amount=it},"Montant FCFA",Modifier.fillMaxWidth())
 Button(onClick={val a=amount.toLongOrNull();if(label.isNotBlank()&&a!=null&&a>0)scope.launch{dao.addExpense(Expense(label=label.trim(),amount=a));label="";amount=""}},modifier=Modifier.fillMaxWidth()){Text("Ajouter")}
 LazyColumn{items(items,key={it.id}){e->ListItem(headlineContent={Text(e.label)},trailingContent={Text(money(e.amount))})}}
}
