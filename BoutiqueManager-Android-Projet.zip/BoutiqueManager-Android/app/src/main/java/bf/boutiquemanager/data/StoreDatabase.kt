package bf.boutiquemanager.data
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class Product(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val buy:Long,val sell:Long,val qty:Int,val alert:Int=3)
@Entity data class Sale(@PrimaryKey(autoGenerate=true) val id:Long=0,val productName:String,val qty:Int,val price:Long,val cost:Long,val customer:String,val seller:String,val date:Long=System.currentTimeMillis())
@Entity data class Expense(@PrimaryKey(autoGenerate=true) val id:Long=0,val label:String,val amount:Long,val date:Long=System.currentTimeMillis())

@Dao interface StoreDao {
 @Query("SELECT * FROM Product ORDER BY name") fun products():Flow<List<Product>>
 @Query("SELECT * FROM Sale ORDER BY date DESC") fun sales():Flow<List<Sale>>
 @Query("SELECT * FROM Expense ORDER BY date DESC") fun expenses():Flow<List<Expense>>
 @Insert suspend fun addProduct(p:Product)
 @Insert suspend fun addSale(s:Sale)
 @Insert suspend fun addExpense(e:Expense)
 @Query("UPDATE Product SET qty=qty-:n WHERE id=:id AND qty>=:n") suspend fun decrease(id:Long,n:Int):Int
 @Delete suspend fun delete(p:Product)
}
@Database(entities=[Product::class,Sale::class,Expense::class],version=1,exportSchema=false)
abstract class StoreDatabase:RoomDatabase(){
 abstract fun dao():StoreDao
 companion object {
  @Volatile private var instance:StoreDatabase?=null
  fun get(c:Context)=instance?: synchronized(this){instance?:Room.databaseBuilder(c.applicationContext,StoreDatabase::class.java,"boutiquemanager.db").build().also{instance=it}}
 }
}
